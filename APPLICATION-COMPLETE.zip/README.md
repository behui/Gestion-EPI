# 🏭 Gestion Casiers & Équipements PPVE

Système complet de gestion des casiers et équipements de ventilation avec authentification Firebase.

## 📋 Fichiers du Système

### Pages Principales
- **`login.html`** - Page de connexion (point d'entrée)
- **`gestion-casiers.html`** - Application principale (nécessite authentification)
- **`admin.html`** - Gestion des utilisateurs (admins uniquement)
- **`Antho.html`** - Gestion des équipements (intégré dans gestion-casiers.html)

### Pages Utilitaires
- **`setup-admin.html`** - Créer le premier administrateur (utiliser une seule fois)
- **`test-firebase.html`** - Tester la connexion Firebase
- **`firestore.rules`** - Règles de sécurité Firestore

---

## 🚀 Installation (Première Utilisation)

### Étape 1 : Configurer Firebase

1. **Activer Firebase Authentication**
   - Allez sur : https://console.firebase.google.com/project/gestion-epi-4387a/authentication/providers
   - Cliquez sur "Email/Password"
   - Activez le premier bouton
   - Cliquez "Save"

2. **Configurer les règles Firestore**
   - Allez sur : https://console.firebase.google.com/project/gestion-epi-4387a/firestore/rules
   - Copiez le contenu de `firestore.rules`
   - Collez-le dans l'éditeur
   - Cliquez "Publier"

### Étape 2 : Créer le Premier Admin

1. **Ouvrez `setup-admin.html` dans votre navigateur**
2. Remplissez le formulaire :
   - Prénom : Anthony
   - Nom : Fernandez
   - Email : votre.email@exemple.com
   - Mot de passe : min. 6 caractères
3. Cliquez "Créer le compte administrateur"
4. **Notez bien vos identifiants !**

### Étape 3 : Se Connecter

1. Ouvrez `login.html`
2. Connectez-vous avec l'email et mot de passe créés
3. Vous serez redirigé vers `gestion-casiers.html`

---

## 👥 Rôles et Permissions

### 🔑 Administrateur
- ✅ Accès à tous les onglets
- ✅ Gestion des casiers (attribuer, activer, désactiver)
- ✅ Gestion des équipements (masques, tuyaux, moteurs, batteries)
- ✅ Création/suppression d'utilisateurs
- ✅ Vue d'ensemble complète

### 👤 Utilisateur
- ✅ Consultation de l'espace utilisateur
- ✅ Vue des casiers EN ATTENTE, OCCUPÉS, INACTIFS
- ❌ Pas d'accès à la vue d'ensemble
- ❌ Pas d'accès à la gestion des équipements
- ❌ Pas d'accès à la gestion des utilisateurs

---

## 📱 Utilisation

### Pour les Admins

#### Créer un Utilisateur
1. Connectez-vous en tant qu'admin
2. Cliquez sur "👤 Gestion Utilisateurs"
3. Remplissez le formulaire
4. Choisissez le rôle (Admin ou Utilisateur)
5. Cliquez "Créer l'utilisateur"
6. **Communiquez les identifiants à la personne**

#### Gérer les Casiers
1. Onglet "📊 Vue d'Ensemble Casiers"
2. Filtrez par plateforme (CI, CA-A, CA-B, CA-C)
3. **Attribuer** : Cliquez sur un casier LIBRE
4. **Activer** : Validez un casier EN ATTENTE (checklist de vérification)
5. **Désactiver** : Passez un casier OCCUPÉ en INACTIF (nettoyage)
6. **Réactiver** : Remettez un casier INACTIF en LIBRE

#### Gérer les Équipements
1. Onglet "🎭 Gestion Équipements"
2. 4 catégories : Masques, Tuyaux, Moteurs, Batteries
3. **Ajouter** : Stock ou Utilisation directe
4. **Maintenance** : Enregistrer les maintenances
5. **Mise en service** : Passer de Stock → Utilisation (3 ans)
6. **Export** : Excel (Power BI) ou PDF (audit)

### Pour les Utilisateurs

1. Connectez-vous avec vos identifiants
2. Vous arrivez automatiquement sur "👤 Espace Utilisateur"
3. Consultez les casiers EN ATTENTE, OCCUPÉS, INACTIFS
4. Filtrez par statut

---

## 🔄 Synchronisation Temps Réel

✅ Toutes les modifications sont synchronisées instantanément entre tous les utilisateurs connectés
✅ Backup automatique dans localStorage
✅ Fonctionne sur plusieurs ordinateurs/navigateurs simultanément

---

## 🌐 Déploiement sur GitHub Pages

1. Créez un repository GitHub
2. Uploadez tous les fichiers HTML
3. Activez GitHub Pages (Settings > Pages)
4. **Renommez `login.html` en `index.html`** pour que ce soit la page d'accueil
5. Votre URL : `https://votre-username.github.io/nom-du-repo/`

---

## 🔒 Sécurité

- ✅ Authentification obligatoire pour accéder à l'application
- ✅ Règles Firestore basées sur les rôles
- ✅ Validation côté client et serveur
- ✅ Sessions sécurisées avec Firebase Auth
- ⚠️ Pour la production, ajoutez des règles Firestore plus strictes

---

## 📊 Structure de Données

### Collection `casiers`
```javascript
{
  lockers: [
    {
      id: "C01",
      platform: "CI",
      statut: "LIBRE" | "EN ATTENTE" | "OCCUPÉ" | "INACTIF",
      prenom: "",
      nom: "",
      refMasque: "",
      refTuyau: "",
      date: ""
    }
  ],
  lastUpdate: "2025-12-11T14:00:00.000Z"
}
```

### Collection `users`
```javascript
{
  uid: "xK9pL2mN3oP4qR5s",
  prenom: "Anthony",
  nom: "Fernandez",
  email: "admin@exemple.com",
  role: "admin" | "utilisateur",
  createdAt: "2025-12-11T14:00:00.000Z"
}
```

### Collection équipements (localStorage dans Antho.html)
```javascript
{
  masques: [...],
  tuyaux: [...],
  moteurs: [...],
  batteries: [...]
}
```

---

## 🛠️ Dépannage

### Problème : "Permission denied"
➡️ Vérifiez que les règles Firestore sont bien configurées (voir firestore.rules)

### Problème : "Pas de redirection après login"
➡️ Vérifiez que la collection `users` contient bien votre UID avec un rôle

### Problème : "Setup admin ne fonctionne pas"
➡️ Vérifiez que Firebase Authentication Email/Password est activé

### Problème : "Les données ne se synchronisent pas"
➡️ Ouvrez la console (F12) et vérifiez les messages d'erreur

---

## 📞 Support

Pour toute question ou problème :
1. Ouvrez la console du navigateur (F12)
2. Regardez les messages d'erreur
3. Vérifiez la configuration Firebase
4. Testez avec `test-firebase.html`

---

## 📝 Changelog

### Version 1.0 (2025-12-11)
- ✅ Système d'authentification Firebase
- ✅ Gestion des rôles (Admin/Utilisateur)
- ✅ Gestion des casiers (288 casiers)
- ✅ Gestion des équipements (Masques, Tuyaux, Moteurs, Batteries)
- ✅ Synchronisation temps réel
- ✅ Interface utilisateur responsive
- ✅ Export Excel et PDF
- ✅ Historique des maintenances

---

## 🎯 Prochaines Fonctionnalités

- [ ] Notifications par email
- [ ] Rapports automatiques mensuels
- [ ] Statistiques avancées
- [ ] Gestion des réservations
- [ ] Application mobile (PWA)
- [ ] Import CSV/Excel
- [ ] QR Codes pour les casiers

---

**Développé pour la gestion PPVE - 2025**
